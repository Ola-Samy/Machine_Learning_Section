import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Data
X = np.array([[2], [4], [6], [8], [10]])
y = np.array([40, 50, 65, 80, 90])

# Train model
model = LinearRegression()
model.fit(X, y)

# Predict
print("Grade after 7 hours:", model.predict([[7]]))

# Evaluate
pred = model.predict(X)

print("MAE:", mean_absolute_error(y, pred))
print("MSE:", mean_squared_error(y, pred))
print("R2:", r2_score(y, pred))



#lec 2 amin mohammed mohammed
