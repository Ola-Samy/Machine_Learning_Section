import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# Data points
X = np.array([
    [1, 1], [1.5, 2], [3, 3.5],
    [5, 7], [3.5, 5], [4.5, 5], [3.5, 4.5]
])

# Train K-Means
model = KMeans(n_clusters=2, random_state=42, n_init=10)
model.fit(X)

# Results
print("Clusters:", model.labels_)
print("Centers:\n", model.cluster_centers_)
print("Inertia:", model.inertia_)
print("Silhouette Score:", silhouette_score(X, model.labels_))

#lec 3
